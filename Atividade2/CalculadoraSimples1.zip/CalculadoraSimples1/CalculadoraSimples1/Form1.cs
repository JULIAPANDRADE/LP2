﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraSimples1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
                    }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") // if (textBox1.Text==String.Empty)
                MessageBox.Show("O número 1 está vazio");
            else
                MessageBox.Show("O número 1 é  : " + textBox1.Text);
                MessageBox.Show("O limpar está vazio");
            if (textBox2.Text == "") // if (textBox2.Test==String.Empty)
                MessageBox.Show("O número 2 está vazio");
            else
                MessageBox.Show("O número 2 é : " + textBox2.Text);
                MessageBox.Show("O sair está vazio");
            if (textBox3.Text == "") // if (textBox3.Test==String.Empty)
                MessageBox.Show("O resultado está vazio");
            else
                MessageBox.Show("O resultado é " + textBox3.Text);
                MessageBox.Show("O + está vazio");
                MessageBox.Show("O - está vazio");
                MessageBox.Show("O * está vazio");
                MessageBox.Show("O / está vazio");


        }
    }
}
